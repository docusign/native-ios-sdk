#import <DocuSignSDK/DSMTab.h>

@interface DSMEnvelopeTab : DSMTab

- (instancetype)init NS_UNAVAILABLE;

@end


