#import <Foundation/Foundation.h>

#pragma mark - USER Error Constants
extern NSString * const DSM_USER_ADDITIONAL_DATA_FETCH_ERROR;
extern NSString * const DSM_USER_LOGIN_ERROR;
extern NSString * const DSM_USER_PERSIST_ERROR;
extern NSString * const DSM_USER_DATA_FETCH_ERROR;
extern NSString * const DSM_USER_DATA_DELETE_ERROR;
extern NSString * const DSM_USER_NOT_LOGGED_IN_ERROR;

#pragma mark - SDK Error Constants
extern NSString * const DSM_SDK_SETUP_ERROR;
extern NSString * const DSM_SDK_FETCH_ERROR;

#pragma mark - Template Error Constants
extern NSString * const DSM_TEMPLATE_IMPORT_ERROR;
extern NSString * const DSM_TEMPLATE_SAVE_ERROR;
extern NSString * const DSM_TEMPLATE_SEND_ERROR;
extern NSString * const DSM_TEMPLATE_SIGN_ERROR;
extern NSString * const DSM_TEMPLATE_ENVELOPE_DEFAULTS_ERROR;


#pragma mark - Document Creation error Constants
extern NSString * const DSM_DOCUMENT_INVALID_TYPE_ERROR;
extern NSString * const DSM_DOCUMENT_EXCEEDS_LIMIT_ERROR;
extern NSString * const DSM_DOCUMENT_GENERIC_ERROR;
