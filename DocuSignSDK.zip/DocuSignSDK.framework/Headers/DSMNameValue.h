#import <Foundation/Foundation.h>

/*!
 @class DSMNameValue
 */
@interface DSMNameValue : NSObject
/*!
 * @brief TODO:Doc
 */
@property (nonatomic, copy) NSString *name;
/*!
 * @brief Specifies the value of the tab. [optional]
 */
@property (nonatomic, copy) NSString *value;

@end
