#import "DSMTabFrame.h"

@interface DSMTabFrame (Additions)

- (instancetype)initWithOriginX:(NSNumber *)x originY:(NSNumber *)y width:(NSNumber *)width height:(NSNumber *)height originYOffsetApplied:(NSNumber *)originYOffsetApplied;

@end
