#import <Foundation/Foundation.h>
#import "DSMEnvelopeTemplate.h"

@interface DSMEnvelopeDefinition : DSMEnvelopeTemplate

@property (nonatomic, strong) NSString *envelopeName;

@end
