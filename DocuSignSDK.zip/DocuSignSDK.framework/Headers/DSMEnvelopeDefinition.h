#import <Foundation/Foundation.h>
#import "DSMEnvelopeTemplate.h"

@interface DSMEnvelopeDefinition : DSMEnvelopeTemplate

@end
