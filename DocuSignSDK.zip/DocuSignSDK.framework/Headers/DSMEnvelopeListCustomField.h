#import <DocuSignSDK/DSMListCustomField.h>

@interface DSMEnvelopeListCustomField : DSMListCustomField

- (instancetype) init NS_UNAVAILABLE;

@end

