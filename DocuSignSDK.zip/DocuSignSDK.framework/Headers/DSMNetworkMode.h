#ifndef DSMNetworkMode_h
#define DSMNetworkMode_h

#import <Foundation/Foundation.h>

extern NSString * const DSMNetworkModeOnlineValue;
extern NSString * const DSMNetworkModeOfflineValue;

/*!
 * @typedef DSMNetworkMode
 * @brief Supported Network modes for login methods.
 * @constant DSMNetworkModeOnline, default value, represent state when network is online.
 * @constant DSMNetworkModeOffline, represents state when network is offline.
 * @see DSMManager.h
 */
typedef NS_ENUM(NSUInteger, DSMNetworkMode) {
    DSMNetworkModeOnline,
    DSMNetworkModeOffline
};

#endif /* DSMNetworkMode_h */

