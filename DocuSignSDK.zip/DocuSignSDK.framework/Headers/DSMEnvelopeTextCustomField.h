#import <DocuSignSDK/DSMTextCustomField.h>

@interface DSMEnvelopeTextCustomField : DSMTextCustomField

- (instancetype) init NS_UNAVAILABLE;

@end

