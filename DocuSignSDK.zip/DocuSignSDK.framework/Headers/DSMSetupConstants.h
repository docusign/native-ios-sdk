#import <Foundation/Foundation.h>

#pragma mark - Setup Constants - Contacts access
/*!
 * @brief Disable contacts access from SDK to override the default behaviour. Default behaviour is to use contacts and it would show permission prompt related to
 * NSContactsUsageDescription. Info plist should have a NSContactsUsageDescription entry to avoid crash.
 * @see DSMManager
 */
extern NSString * const DSM_SETUP_DISABLE_CONTACTS_USAGE_KEY;

/*! @brief "true" representing BOOL true.
 */
extern NSString * const DSM_SETUP_TRUE_VALUE;

/*! @brief "false" representing BOOL false.
 */
extern NSString * const DSM_SETUP_FALSE_VALUE;

#pragma mark - Setup Constants - Offline
/*!
 * @brief Hide all of the alerts that are shown during offline signing. Default behaviour is to show all alerts during offline signing.
 * Acceptable value is either "true" or "false".
 */
extern NSString * const DSM_SETUP_OFFLINE_SIGNING_HIDE_ALERTS_KEY;

/*!
 * @brief Enable UI components to switch recipients during offline signing of an envelope. Default behaviour is to have ui components to switch recipients disabled during offline signing.
 * Acceptable value is either "true" or "false".
 */
extern NSString * const DSM_SETUP_OFFLINE_SIGNING_HIDE_SWITCH_RECIPIENT_UI_KEY;

#pragma mark - Setup Constants - Offline Tab Conversion
/*!
 * @brief Allow templates with unsupported offline v1 tab types to set mergeField info as nil during auto-conversion.
 * Default value is "false".
 * Acceptable value is either "true" or "false".
 */
extern NSString * const DSM_SETUP_OFFLINE_SIGNING_SET_MERGEFIELD_AS_NIL_FOR_TABS_CONVERSION;

/*!
 * @brief Allow templates with ziptabs to be downloaded for offline signing. Enabling this would autoconvert the ziptabs to the texttabs and remove any mergefield info if DSM_SETUP_OFFLINE_SIGNING_SET_MERGEFIELD_AS_NIL_FOR_TABS_CONVERSION is set as "true".
 * Default value is "false".
 * Acceptable value is either "true" or "false".
 */
extern NSString * const DSM_SETUP_OFFLINE_SIGNING_CONVERT_ZIPTABS_TO_TEXTTABS;

/*!
 * @brief Allow use of document picker when selecting documents for composing offline envelopes. Enabling this requires iCloud entitlement to be enabled along with iCloud Documents if DSM_SETUP_ICLOUD_DOCUMENT_ENABLED is set as "true".
 * Default value is "false".
 * Acceptable value is either "true" or "false".
 */
extern NSString * const DSM_SETUP_ICLOUD_DOCUMENT_ENABLED;

/*!
 * @brief Allow templates with numberTabs to be downloaded for offline signing. Enabling this would autoconvert the numberTabs to the texttabs and remove any mergefield info if DSM_SETUP_OFFLINE_SIGNING_SET_MERGEFIELD_AS_NIL_FOR_TABS_CONVERSION is set as "true".
 * Default value is "false".
 * Acceptable value is either "true" or "false".
 */
extern NSString * const DSM_SETUP_OFFLINE_SIGNING_CONVERT_NUMBERTABS_TO_TEXTTABS;

/*!
 * @brief Allow templates with emailTabs to be downloaded for offline signing. Enabling this would autoconvert the emailtabs to the texttabs and remove any mergefield info if DSM_SETUP_OFFLINE_SIGNING_SET_MERGEFIELD_AS_NIL_FOR_TABS_CONVERSION is set as "true".
 * Default value is "false".
 * Acceptable value is either "true" or "false".
 */
extern NSString * const DSM_SETUP_OFFLINE_SIGNING_CONVERT_EMAILTABS_TO_TEXTTABS;

/*!
 * @brief Allow templates with dateTabs to be downloaded for offline signing. Enabling this would autoconvert the dateTabs to the texttabs and remove any mergefield info if DSM_SETUP_OFFLINE_SIGNING_SET_MERGEFIELD_AS_NIL_FOR_TABS_CONVERSION is set as "true".
 * Default value is "false".
 * Acceptable value is either "true" or "false".
 */
extern NSString * const DSM_SETUP_OFFLINE_SIGNING_CONVERT_DATETABS_TO_TEXTTABS;

/*!
 * @brief Allows display of Powered By DocuSign footer. Enabling this would display the footer for Online and Offline signing if DSM_SETUP_POWERED_BY_DOCUSIGN_ENABLED is set as "true".
 * Default value is "true".
 * Acceptable value is either "true" or "false".
 */
extern NSString * const DSM_SETUP_POWERED_BY_DOCUSIGN_ENABLED;

/*!
 * @brief Allow templates with readonly and required text based tabs with nil value to be auto-converted to non-readonly text based tabs. Enabling this would autoconvert the text based tabs and set the bool locked (i.e. readonly) flag for such tabs to true if DSM_SETUP_OFFLINE_SIGNING_CONVERT_INVALID_READONLY_REQUIRED_TEXTTABS_TO_EDITABLE is set as "true".
 * Default value is "true".
 * Acceptable value is either "true" or "false".
 */
extern NSString * const DSM_SETUP_OFFLINE_SIGNING_CONVERT_INVALID_READONLY_REQUIRED_TEXTTABS_TO_EDITABLE;

/*! @brief Use a placeholder string indicative of tab-type (e.g. "Text", "Company", etc) instead of showing empty string for text based tabs with empty value.
 * Default value is "true".
 * Acceptable value is either "true" or "false".
 */
extern NSString * const DSM_SETUP_OFFLINE_SIGNING_USE_PLACEHOLDER_TAB_VALUE;

/*! @brief Allows Next button on offline signing ceremony to navigate and focus only on empty required fields.
 * Default value is "false".
 * Acceptable value is either "true" or "false".
 * Refer [Auto-Navigation]: https://support.docusign.com/en/guides/ndse-admin-guide-signing-settings
 */
extern NSString * const DSM_SETUP_OFFLINE_SIGNING_NAVIGATE_BLANK_REQUIRED_FIELDS;
