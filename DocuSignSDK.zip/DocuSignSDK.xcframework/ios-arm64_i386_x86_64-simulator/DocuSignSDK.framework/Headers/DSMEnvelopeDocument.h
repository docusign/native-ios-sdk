#import <DSMDocument.h>

@interface DSMEnvelopeDocument : DSMDocument

- (instancetype)init NS_UNAVAILABLE;

@end


