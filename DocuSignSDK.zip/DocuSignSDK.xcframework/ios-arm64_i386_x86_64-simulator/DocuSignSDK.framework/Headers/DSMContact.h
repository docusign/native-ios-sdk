
@interface DSMContact : NSObject

@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *emailType;
@property (nonatomic, strong) NSString *email;

@end
