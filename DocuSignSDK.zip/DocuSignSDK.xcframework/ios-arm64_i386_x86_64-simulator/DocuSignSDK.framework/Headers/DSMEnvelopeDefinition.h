#import <Foundation/Foundation.h>
#import <DocuSignSDK/DSMEnvelopeTemplate.h>

@interface DSMEnvelopeDefinition : DSMEnvelopeTemplate

@property (nonatomic, strong) NSString *envelopeName;

@end
