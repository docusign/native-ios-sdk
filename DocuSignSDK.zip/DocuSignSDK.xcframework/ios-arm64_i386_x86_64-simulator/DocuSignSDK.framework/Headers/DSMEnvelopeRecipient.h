#import <DocuSignSDK/DSMRecipient.h>

@interface DSMEnvelopeRecipient : DSMRecipient

- (instancetype)init NS_UNAVAILABLE;

@end

